/**
 * Import blocks as components
 */

import "./alert";
import "./blockquote";
import "./call-to-action";
import "./card";
import "./testimonial";